package com.uasz.Emploie_Du_Temps;

import jakarta.persistence.*;

import java.util.Date;

@Entity
public class Deroulement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String matiere;
    private String date;
    private String processus;

    @OneToOne
    private Seance seance;
}
