package com.uasz.Emploie_Du_Temps;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Repartition {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String classe;
    private int effectif;
    private  int semestre;
    private String uniteEnseignement;
    private int credit;
    private int dureeCours;
    private String Enseignant;
    private int cm;
    private String ResponsableTD;
    private String ResponsableTP;
    private int travauxDirige;
    private int travauxPratique;
    @OneToMany(mappedBy = "repatition")
    private List<Seance> seances;
}
