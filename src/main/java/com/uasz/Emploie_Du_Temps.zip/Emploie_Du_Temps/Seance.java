package com.uasz.Emploie_Du_Temps;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
public class Seance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String titre;
    private LocalDateTime dateDebut;
    private LocalDateTime dateFin;

    @ManyToOne
    private Emploi emploi;
    @OneToOne(mappedBy = "seance")
    private Deroulement deroulement ;
    @ManyToOne
    private Repartition repartition;
}
