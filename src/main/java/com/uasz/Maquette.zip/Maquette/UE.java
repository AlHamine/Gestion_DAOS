package com.uasz.Maquette;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UE {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  Long id;
    private String libelle;
    private String Code;
    private String description;
    @OneToMany(mappedBy = "ue")
    private List<EC> ecs;
    @OneToMany(mappedBy = "ue")
    private List<Module>module;


}
