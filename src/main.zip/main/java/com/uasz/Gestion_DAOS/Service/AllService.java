package com.uasz.Gestion_DAOS.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uasz.Gestion_DAOS.Service.Emploie_Du_Temps.BatimentService;
import com.uasz.Gestion_DAOS.Service.Emploie_Du_Temps.DeroulementService;
import com.uasz.Gestion_DAOS.Service.Emploie_Du_Temps.EmploiService;
import com.uasz.Gestion_DAOS.Service.Emploie_Du_Temps.SalleService;
import com.uasz.Gestion_DAOS.Service.Emploie_Du_Temps.SeanceService;
import com.uasz.Gestion_DAOS.Service.Maquette.CycleService;
import com.uasz.Gestion_DAOS.Service.Maquette.ECService;
import com.uasz.Gestion_DAOS.Service.Maquette.EnseignementService;
import com.uasz.Gestion_DAOS.Service.Maquette.FiliereService;
import com.uasz.Gestion_DAOS.Service.Maquette.FormationService;
import com.uasz.Gestion_DAOS.Service.Maquette.GroupeService;
import com.uasz.Gestion_DAOS.Service.Maquette.MaquetteService;
import com.uasz.Gestion_DAOS.Service.Maquette.ModuleService;
import com.uasz.Gestion_DAOS.Service.Maquette.NiveauService;
import com.uasz.Gestion_DAOS.Service.Maquette.SemestreService;
import com.uasz.Gestion_DAOS.Service.Maquette.UEService;
import com.uasz.Gestion_DAOS.Service.Repartition.EnseignantService;
import com.uasz.Gestion_DAOS.Service.Repartition.PERService;
import com.uasz.Gestion_DAOS.Service.Repartition.RepartitionService;
import com.uasz.Gestion_DAOS.Service.Repartition.VacataireService;


// @Data 
@Service
public class AllService {
    @Autowired
    public UEService ueService;
    @Autowired
    public SemestreService semestreService;
    @Autowired
    public PERService perService;
    @Autowired
    public EnseignantService enseignantService;
    @Autowired
    public VacataireService vacataireService;
    @Autowired
    public RepartitionService repartitionService;
    @Autowired
    public NiveauService niveauService;
    @Autowired
    public ModuleService moduleService;
    @Autowired
    public MaquetteService maquetteService;
    @Autowired
    public GroupeService groupeService;
    @Autowired
    public FormationService formationService;
    @Autowired
    public FiliereService filiereService;
    @Autowired
    public EnseignementService enseignementService;
    @Autowired
    public ECService ecservice;
    @Autowired
    public CycleService cycleService;
    @Autowired
    public BatimentService batimentService;
    @Autowired
    public DeroulementService deroulementService;
    @Autowired
    public EmploiService emploiService;
    @Autowired
    public SalleService salleService;
    @Autowired
    public SeanceService seanceService;




}
