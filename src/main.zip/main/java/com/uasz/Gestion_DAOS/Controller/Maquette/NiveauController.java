package com.uasz.Gestion_DAOS.Controller.Maquette;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.uasz.Gestion_DAOS.Service.Maquette.NiveauService;
import com.uasz.Gestion_DAOS.model.Maquette.Niveau;


@Controller
public class NiveauController {

    @Autowired
    private NiveauService niveauService;

    @RequestMapping(value = "/niveau", method = RequestMethod.GET)
    public String lister_niveau(Model model) {
        List<Niveau> niveauList = niveauService.afficherToutNiveau();
        model.addAttribute("listeDesNiveau", niveauList);
        return "niveau";
    }

    @RequestMapping(value = "/ajouter_niveau", method = RequestMethod.POST)
    public String ajouter_niveau(Model modele, Niveau niveau) {
        niveauService.ajouterNiveau(niveau);
        return "redirect:/niveau";
    }
    @RequestMapping(value = "/supprimer_niveau", method = RequestMethod.GET)
    public String supprimer_niveau(Model modele, @RequestParam(name = "id") Long id) {
        // ueService.modifierUE(ue);
        Boolean ok = niveauService.suprimerNiveau(id);

        return "redirect:/niveau";
    }
}

